package com.gritlab.quizapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    int score = QuestionActivity.getScore();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        setScore();
        setRank();

    }

    //Checks score and returns the value
    public void setScore() {

        TextView textView = findViewById(R.id.score);

        switch (score) {
            case 0:
                textView.setText("0/5");
                break;
            case 1:
                textView.setText("1/5");
                break;
            case 2:
                textView.setText("2/5");
                break;
            case 3:
                textView.setText("3/5");
                break;
            case 4:
                textView.setText("4/5");
                break;
            case 5:
                textView.setText("5/5");
                break;
        }
    }

    public void setRank() {

        TextView textView = findViewById(R.id.rank);


        //Checks score and returns corresponding rank
        switch (score) {
            case 0:
                textView.setText(R.string.Muggle);
                break;
            case 1:
                textView.setText(R.string.Wookie);
                break;
            case 2:
                textView.setText(R.string.NewBie);
                break;
            case 3:
                textView.setText(R.string.Enthusiast);
                break;
            case 4:
                textView.setText(R.string.pro);
                break;
            case 5:
                textView.setText(R.string.legend);
                break;
        }
    }
}
