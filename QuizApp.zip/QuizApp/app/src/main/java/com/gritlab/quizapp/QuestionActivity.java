package com.gritlab.quizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.TextView;

public class QuestionActivity extends AppCompatActivity {

    static int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
    }

    @Override
    protected void onResume(){
        super.onResume();
        reset();
    }

    // Method evaluates score and starts the ResultActivity

    public void result(View v) {
        editTextQuestion();
        question4CheckBox();
        question5CheckBox();
        Intent intent = new Intent(this, ResultActivity.class);
        startActivity(intent);
    }


    //Method resets all inputs in the question class

    public void reset(View v) {
        score = 0;
        radioGroupReset();
        question4CheckBoxReset();
        question5CheckBoxReset();
        editTextQuestionReset();
    }

    public void reset() {
        score = 0;
        radioGroupReset();
        question4CheckBoxReset();
        question5CheckBoxReset();
        editTextQuestionReset();
    }

    //Increases score by 1
    public void increment(View v) {
        score++;
    }

    public void question4CheckBox() {
        CheckBox checkBox1 = findViewById(R.id.q4c1);
        CheckBox checkBox2 = findViewById(R.id.q4c2);
        CheckBox checkBox3 = findViewById(R.id.q4c3);
        CheckBox checkBox4 = findViewById(R.id.q4c4);

        boolean q4c1 = checkBox1.isChecked();
        boolean q4c2 = checkBox2.isChecked();
        boolean q4c3 = checkBox3.isChecked();
        boolean q4c4 = checkBox4.isChecked();

        //Checks that the wrong boxes are not selected
        if (q4c1 || q4c2)
            return;
        if (q4c3 & q4c4)
            score++;
    }

    public void question4CheckBoxReset() {
        CheckBox checkBox1 = findViewById(R.id.q4c1);
        CheckBox checkBox2 = findViewById(R.id.q4c2);
        CheckBox checkBox3 = findViewById(R.id.q4c3);
        CheckBox checkBox4 = findViewById(R.id.q4c4);

        //Sets all CheckBoxes to unchecked state
        checkBox1.setChecked(false);
        checkBox2.setChecked(false);
        checkBox3.setChecked(false);
        checkBox4.setChecked(false);

    }

    public void question5CheckBox() {
        CheckBox checkBox1 = findViewById(R.id.q5c1);
        CheckBox checkBox2 = findViewById(R.id.q5c2);
        CheckBox checkBox3 = findViewById(R.id.q5c3);
        CheckBox checkBox4 = findViewById(R.id.q5c4);

        boolean q5c1 = checkBox1.isChecked();
        boolean q5c2 = checkBox2.isChecked();
        boolean q5c3 = checkBox3.isChecked();
        boolean q5c4 = checkBox4.isChecked();

        //Checks that the wrong answer isn't selected
        if (q5c2 || q5c4)
            return;
        if (q5c1 & q5c3)
            score++;
    }

    public void question5CheckBoxReset() {
        CheckBox checkBox1 = findViewById(R.id.q5c1);
        CheckBox checkBox2 = findViewById(R.id.q5c2);
        CheckBox checkBox3 = findViewById(R.id.q5c3);
        CheckBox checkBox4 = findViewById(R.id.q5c4);

        //Sets all CheckBoxes to unchecked state
        checkBox1.setChecked(false);
        checkBox2.setChecked(false);
        checkBox3.setChecked(false);
        checkBox4.setChecked(false);

    }

    //Checks that the correct answer was typed in the EditText view then increments score
    public void editTextQuestion() {
        TextView editTextView = findViewById(R.id.editable_text_view);
        String question4Answer = editTextView.getText().toString();

        if (question4Answer.equalsIgnoreCase("int"))
            score++;
    }

    //Sets the EditText view to null
    public void editTextQuestionReset() {
        TextView editTextView = findViewById(R.id.editable_text_view);
        editTextView.setText(null);
    }

    public void radioGroupReset(){
        RadioGroup radioGroup1 = findViewById(R.id.radio_group_1);
        RadioGroup radioGroup2 = findViewById(R.id.radio_group_2);
        RadioGroup radioGroup3 = findViewById(R.id.radio_group_3);
        radioGroup1.clearCheck();
        radioGroup2.clearCheck();
        radioGroup3.clearCheck();

    }
    public static int getScore() {
        return score;
    }

}
